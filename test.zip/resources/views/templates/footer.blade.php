
{{-- Начало области шапку --}}
<footer class="footer py-4 mt-5 bg-light">
    <div class="container">
        <div class="row">
            <div class="col text-muted">Test</div>
        </div>
    </div>
</footer>
{{-- Окончание области шапку --}}
